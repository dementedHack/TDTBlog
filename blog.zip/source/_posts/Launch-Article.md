---
title: "The Dev Techs Blog Has Launched!"
catalog: true
date: 2017-07-21 
subtitle: "Your Source for Current Tech News"
header-img: "laptop.jpg"
tags:
- Blog
- News
- Hexo
catagories:
- Updates
---
> Find our home site at [The Dev Techs](www.thedevtechs.com)

# Summary
---
We just wanted to announce to our followers that we have started a blog. The videos posted on our YouTube channel have been fairly popular, and it’s time that we branch out. We hope to continue to aid other developers, and hope to instill trust in current and future customers through our blog posts.

Tutorials and reviews to come in the future!

![BeanTech Desktop](http://beantech.org/img/beantech-desktop.png)
