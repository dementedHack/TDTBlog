---
title: "TDT Website Uses Serverless Technologies"
catalog: true
date: 2017-07-21 
subtitle: "S3, Lambda, and Hexo..."
header-img: "laptop.jpg"
tags:
- AWS
- S3
- Lambda
- Hexo
catagories:
- Updates
---

# AWS and Serverless Technologies for Web Applications:
---
That’s right! We’ve started to take advantage of this technology to host our site and blog. We can host our applications without the need to worry about the underlying infrastructure. Scaling and security is handled (mostly) by the host – in our case Amazon Web Services. In a later post I’ll dive deeper into the exact architecture and explain how to create a serverless website.

Tutorials and reviews to come in the future!

![Serverless](https://f5.com/Portals/1/Users/038/38/38/serverless%20Cropped.png)
