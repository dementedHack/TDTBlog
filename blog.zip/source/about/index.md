---
layout: "about"
title: "About"
date: 2016-04-21 04:48:33
description: "Wish for the Best, Prepare for the Worst"
header-img: "img/header_img/Iron-Man-3.jpg"
comments: true
---

> 光有好奇心而不去實踐，等於自願放棄成功機會
> 別為自己畫地自限，Just Do It！！
